const module2Questions = [

{
id:17,
module:2,
lesson:1,
category:"Applications",
difficulty:"Easy",
product:"",
question:"Smoke detectors are commonly installed to provide what benefit?",
answers:[
"Early warning of possible fire conditions",
"Additional HVAC airflow",
"Power for speakers",
"Emergency lighting"
],
correct:0,
explanation:"Smoke detection is intended to provide early warning so occupants can respond appropriately."
},

{
id:19,
module:2,
lesson:1,
category:"Applications",
difficulty:"Medium",
product:"",
question:"Why are smoke detectors installed throughout a building instead of only at the fire alarm panel?",
answers:[
"They must detect smoke where a fire could occur.",
"They improve battery charging.",
"They increase speaker volume.",
"They reduce network traffic."
],
correct:0,
explanation:"Detection is needed near potential fire locations throughout the protected building."
},

{
id:20,
module:2,
lesson:1,
category:"Review",
difficulty:"Easy",
product:"",
question:"What is the primary purpose of Lesson 1?",
answers:[
"Understanding the role of smoke detectors within a fire alarm system",
"Programming addressable panels",
"Calculating battery sizes",
"Installing conduit"
],
correct:0,
explanation:"Lesson 1 establishes the fundamentals of smoke detection before moving into specific detector technologies."
},

{
id:21,
module:2,
lesson:2,
category:"Detector Technologies",
difficulty:"Easy",
product:"",
question:"What are the two most common smoke detection technologies used in fire alarm systems?",
answers:[
"Photoelectric and Ionization",
"Thermal and Optical",
"Infrared and Ultrasonic",
"Analog and Digital"
],
correct:0,
explanation:"Photoelectric and ionization are the two traditional smoke detection technologies used in fire alarm systems."
},

{
id:22,
module:2,
lesson:2,
category:"Detector Technologies",
difficulty:"Easy",
product:"",
question:"Which smoke detector technology uses a light source and sensor to detect smoke?",
answers:[
"Photoelectric",
"Ionization",
"Heat Detection",
"Carbon Monoxide"
],
correct:0,
explanation:"Photoelectric detectors use a light source and photosensor. Smoke scatters the light onto the sensor, causing an alarm."
},

{
id:23,
module:2,
lesson:2,
category:"Detector Technologies",
difficulty:"Easy",
product:"",
question:"Which smoke detector technology contains a small ionization chamber?",
answers:[
"Ionization",
"Photoelectric",
"Heat Detection",
"Beam Detection"
],
correct:0,
explanation:"Ionization detectors use an ionization chamber to detect changes caused by combustion particles."
},

{
id:24,
module:2,
lesson:2,
category:"Detector Technologies",
difficulty:"Medium",
product:"",
question:"Do all smoke detectors operate using the same sensing technology?",
answers:[
"No",
"Yes",
"Only addressable detectors",
"Only conventional detectors"
],
correct:0,
explanation:"Smoke detectors are manufactured using different sensing technologies depending on their design."
},

{
id:25,
module:2,
lesson:2,
category:"Fundamentals",
difficulty:"Easy",
product:"",
question:"Can both photoelectric and ionization detectors be used in addressable fire alarm systems?",
answers:[
"Yes",
"No",
"Only photoelectric",
"Only ionization"
],
correct:0,
explanation:"Both sensing technologies have been produced in addressable and conventional versions by various manufacturers."
},

{
id:26,
module:2,
lesson:2,
category:"Fundamentals",
difficulty:"Easy",
product:"",
question:"Which device determines what happens after a smoke detector activates?",
answers:[
"Fire Alarm Control Panel",
"The detector itself",
"The notification appliance",
"The battery"
],
correct:0,
explanation:"The control panel receives the detector signal and executes the programmed response."
},

{
id:27,
module:2,
lesson:2,
category:"Detector Technologies",
difficulty:"Medium",
product:"",
question:"Which detector type relies on smoke entering the sensing chamber before it can respond?",
answers:[
"Both photoelectric and ionization detectors",
"Only heat detectors",
"Only duct detectors",
"None of the above"
],
correct:0,
explanation:"Both technologies require smoke to enter the detector in order to sense a fire condition."
},

{
id:28,
module:2,
lesson:2,
category:"Review",
difficulty:"Easy",
product:"",
question:"Which statement is true?",
answers:[
"Different smoke detectors use different sensing technologies.",
"All smoke detectors work exactly the same way.",
"Every smoke detector contains a heat sensor only.",
"Smoke detectors are notification appliances."
],
correct:0,
explanation:"Manufacturers use different sensing technologies depending on the detector design."
},

{
id:29,
module:2,
lesson:2,
category:"Applications",
difficulty:"Medium",
product:"",
question:"Regardless of sensing technology, what is the purpose of every smoke detector?",
answers:[
"Detect smoke and report it to the fire alarm system",
"Activate sprinkler water directly",
"Provide emergency lighting",
"Supply power to speakers"
],
correct:0,
explanation:"All smoke detectors are designed to detect smoke and communicate that condition to the fire alarm system."
},

{
id:30,
module:2,
lesson:2,
category:"Review",
difficulty:"Medium",
product:"",
question:"What is the most important concept from Lesson 2?",
answers:[
"Smoke detectors may use different sensing technologies while performing the same overall function.",
"Every smoke detector works identically.",
"Only one detector technology is used today.",
"Detector technology determines notification volume."
],
correct:0,
explanation:"Although the sensing methods differ, the overall purpose remains the same: detecting smoke and notifying the fire alarm system."
},

{
id:31,
module:2,
lesson:3,
category:"Detector Bases",
difficulty:"Easy",
product:"",
question:"What is the primary purpose of a smoke detector base?",
answers:[
"Provide the mounting and electrical connection for the detector",
"Increase detector sensitivity",
"Power notification appliances",
"Monitor sprinkler valves"
],
correct:0,
explanation:"A detector base provides the physical mounting point and electrical connection between the detector and the fire alarm system."
},

{
id:32,
module:2,
lesson:3,
category:"Detector Bases",
difficulty:"Easy",
product:"",
question:"Can a detector base and detector be separate line items on a Bill of Materials (BOM)?",
answers:[
"Yes",
"No",
"Only on conventional systems",
"Only on retrofit projects"
],
correct:0,
explanation:"Many manufacturers list detectors and their compatible bases as separate products."
},

{
id:33,
module:2,
lesson:3,
category:"BOM Recognition",
difficulty:"Easy",
product:"",
question:"If a project includes smoke detectors, what should you verify during a BOM review?",
answers:[
"Whether the required detector bases are also included",
"That every horn is white",
"That the batteries are installed",
"That the conduit is painted"
],
correct:0,
explanation:"Detector bases are often separate BOM items and should be verified during the review process."
},

{
id:35,
module:2,
lesson:3,
category:"Warehouse",
difficulty:"Easy",
product:"",
question:"A smoke detector base is most commonly found where?",
answers:[
"Mounted to the ceiling or wall where the detector will be installed",
"Inside the fire alarm control panel",
"Inside a speaker enclosure",
"On top of a horn/strobe"
],
correct:0,
explanation:"Detector bases are installed at the detector location before the detector head is attached."
},

{
id:36,
module:2,
lesson:3,
category:"Applications",
difficulty:"Medium",
product:"",
question:"What is normally attached to a detector base after installation?",
answers:[
"A compatible detector",
"A horn",
"A relay",
"A power supply"
],
correct:0,
explanation:"The detector head is installed onto its compatible base."
},

{
id:39,
module:2,
lesson:3,
category:"BOM Recognition",
difficulty:"Hard",
product:"",
question:"A customer says they only need replacement detector heads. What is the first thing you should verify?",
answers:[
"Whether the existing detector bases are compatible with the replacement heads",
"Whether the batteries were replaced",
"The speaker wattage",
"The conduit size"
],
correct:0,
explanation:"Compatibility between detector heads and installed bases should always be confirmed."
},

{
id:40,
module:2,
lesson:3,
category:"Review",
difficulty:"Medium",
product:"",
question:"What is the biggest lesson from detector bases?",
answers:[
"Always verify detector and base compatibility during quoting",
"Detector bases replace notification appliances",
"Detector bases contain batteries",
"Every detector uses the same base"
],
correct:0,
explanation:"Understanding detector/base relationships helps prevent ordering mistakes and installation issues."
},

{
id:43,
module:2,
lesson:4,
category:"HVAC",
difficulty:"Easy",
product:"",
question:"What does HVAC stand for?",
answers:[
"Heating, Ventilation, and Air Conditioning",
"Heat, Voltage, Air Control",
"High Voltage Air Circuit",
"Heating Valve and Cooling"
],
correct:0,
explanation:"HVAC stands for Heating, Ventilation, and Air Conditioning."
},

{
id:45,
module:2,
lesson:4,
category:"Applications",
difficulty:"Easy",
product:"",
question:"A duct smoke detector is primarily associated with which building system?",
answers:[
"HVAC",
"Security",
"Lighting",
"Plumbing"
],
correct:0,
explanation:"Duct smoke detectors are installed as part of HVAC systems."
},

{
id:53,
module:2,
lesson:4,
category:"Applications",
difficulty:"Medium",
product:"",
question:"Why is communication between fire alarm and HVAC systems important?",
answers:[
"It helps limit smoke movement through the building",
"It increases heating efficiency",
"It improves internet speed",
"It reduces lighting costs"
],
correct:0,
explanation:"One purpose of the interface is to help reduce the spread of smoke."
},

{
id:60,
module:2,
lesson:5,
category:"Scenario",
difficulty:"Hard",
product:"",
question:"A project has twelve rooftop units. Before completing the quote, what should you verify?",
answers:[
"That all required fire alarm interfaces have been considered",
"That every smoke detector is white",
"That batteries are installed",
"That conduit sizes match"
],
correct:0,
explanation:"Sales Support should verify that the fire alarm scope properly accounts for HVAC-related equipment."
},

{
id:63,
module:2,
lesson:5,
category:"Applications",
difficulty:"Medium",
product:"",
question:"Why is coordination between mechanical and fire alarm disciplines important?",
answers:[
"Building systems often interact during fire events",
"To improve internet performance",
"To reduce electrical usage",
"To simplify painting"
],
correct:0,
explanation:"HVAC and fire alarm systems are often designed to work together during emergency conditions."
},

{
id:66,
module:2,
lesson:5,
category:"Estimator",
difficulty:"Hard",
product:"",
question:"Which habit is most valuable when reviewing mechanical drawings for fire alarm estimating?",
answers:[
"Look for equipment that may require fire alarm coordination",
"Count ceiling tiles",
"Estimate paint quantities",
"Measure hallway widths"
],
correct:0,
explanation:"Experienced estimators identify building systems that interact with the fire alarm system."
},

{
id:67,
module:2,
lesson:5,
category:"Scenario",
difficulty:"Hard",
product:"",
question:"A project includes several mechanical rooms with large HVAC equipment. What should a Sales Support specialist keep in mind?",
answers:[
"Those systems may require fire alarm interfaces or associated devices",
"Only notification appliances are needed",
"Mechanical rooms never affect the fire alarm system",
"Smoke detectors are not used in commercial buildings"
],
correct:0,
explanation:"Mechanical equipment frequently requires coordination with fire alarm system design."
},

{
id:68,
module:2,
lesson:5,
category:"Review",
difficulty:"Hard",
product:"",
question:"Why is understanding mechanical drawings valuable for Sales Support?",
answers:[
"It helps identify equipment that may affect the fire alarm scope",
"It replaces electrical drawings",
"It determines programming passwords",
"It calculates battery capacity"
],
correct:0,
explanation:"Mechanical drawings provide important context for estimating and product selection."
},

{
id:69,
module:2,
lesson:5,
category:"Scenario",
difficulty:"Hard",
product:"",
question:"You receive a revised mechanical drawing with additional HVAC equipment. What is your first action?",
answers:[
"Review whether the fire alarm BOM needs to be updated",
"Delete existing smoke detectors",
"Increase speaker wattage",
"Replace the batteries"
],
correct:0,
explanation:"Changes to building systems should prompt a review of the associated fire alarm equipment."
},

{
id:70,
module:2,
lesson:5,
category:"Lesson Review",
difficulty:"Medium",
product:"",
question:"What is the primary goal of Lesson 5?",
answers:[
"Learn to recognize HVAC equipment that may affect the fire alarm design",
"Program fire alarm panels",
"Perform detector sensitivity testing",
"Install ductwork"
],
correct:0,
explanation:"This lesson focuses on recognizing building systems that may require fire alarm coordination."
},

{
id:73,
module:2,
lesson:6,
category:"BOM Review",
difficulty:"Hard",
product:"",
question:"The mechanical drawings show extensive ductwork, but you cannot identify any duct smoke detection equipment on the fire alarm documents. What should you do?",
answers:[
"Ask whether duct smoke detection has been addressed in the design",
"Automatically add duct detectors",
"Ignore the difference",
"Remove the ductwork from the estimate"
],
correct:0,
explanation:"Sales Support should identify potential omissions and verify them with the project team rather than making assumptions."
},

{
id:74,
module:2,
lesson:6,
category:"Customer Support",
difficulty:"Medium",
product:"",
question:"A customer asks why you are reviewing both the mechanical drawings and the fire alarm drawings. What is the best explanation?",
answers:[
"Some building systems may require coordination with the fire alarm system",
"Mechanical drawings determine battery size",
"Mechanical drawings replace electrical drawings",
"Fire alarm systems never interact with HVAC systems"
],
correct:0,
explanation:"Reviewing multiple drawing sets helps identify equipment that may affect the fire alarm design."
},

{
id:75,
module:2,
lesson:6,
category:"Scenario",
difficulty:"Hard",
product:"",
question:"During a quote review, you notice the HVAC design changed between drawing revisions. What should you verify?",
answers:[
"Whether the fire alarm equipment should also change",
"Whether the building address changed",
"Whether the parking lot lighting changed",
"Whether the office furniture changed"
],
correct:0,
explanation:"Design revisions in one discipline often require coordination with related systems."
},

{
id:78,
module:2,
lesson:6,
category:"Critical Thinking",
difficulty:"Hard",
product:"",
question:"What is the safest approach when you believe equipment may be missing from a quote?",
answers:[
"Verify the issue with the project documents or design team",
"Automatically add products",
"Ignore the issue",
"Delete related equipment"
],
correct:0,
explanation:"Sales Support should verify potential omissions rather than making assumptions."
},

{
id:80,
module:2,
lesson:6,
category:"Lesson Review",
difficulty:"Medium",
product:"",
question:"What is the primary objective of Lesson 6?",
answers:[
"Learning how to identify project changes that may affect the fire alarm scope",
"Programming control panels",
"Installing smoke detectors",
"Performing acceptance testing"
],
correct:0,
explanation:"Lesson 6 focuses on thinking like a Sales Support specialist by reviewing changes, identifying coordination issues, and verifying project information."
},

{
id:83,
module:2,
lesson:7,
category:"Drawing Review",
difficulty:"Medium",
product:"",
question:"Which discipline's drawings are the best place to identify Air Handling Units (AHUs)?",
answers:[
"Mechanical",
"Civil",
"Architectural",
"Landscape"
],
correct:0,
explanation:"Mechanical drawings typically show HVAC equipment and ductwork."
},

{
id:84,
module:2,
lesson:7,
category:"Critical Thinking",
difficulty:"Hard",
product:"",
question:"A customer asks why you compare multiple drawing sets instead of only reviewing the fire alarm plans. What is the best response?",
answers:[
"Other building systems may affect the fire alarm scope",
"Fire alarm drawings contain every detail for every discipline",
"Mechanical drawings are only for installers",
"There is no reason to compare them"
],
correct:0,
explanation:"Coordination between disciplines helps identify changes that may impact the fire alarm system."
},

{
id:85,
module:2,
lesson:7,
category:"Scenario",
difficulty:"Hard",
product:"",
question:"A revised project adds three new rooftop units. Which action demonstrates good Sales Support practice?",
answers:[
"Review whether the fire alarm equipment list should change",
"Automatically increase detector quantities",
"Ignore the revision until construction",
"Replace notification appliances"
],
correct:0,
explanation:"Design revisions should trigger a review of the fire alarm scope."
},

{
id:87,
module:2,
lesson:7,
category:"Sales Support",
difficulty:"Medium",
product:"",
question:"What is one benefit of reviewing revision clouds on construction drawings?",
answers:[
"They quickly identify what has changed",
"They show battery calculations",
"They identify detector addresses",
"They determine speaker wattage"
],
correct:0,
explanation:"Revision clouds highlight areas that have changed since the previous drawing issue."
},

{
id:88,
module:2,
lesson:7,
category:"Estimator",
difficulty:"Hard",
product:"",
question:"When multiple project documents appear to conflict, what is the most appropriate action?",
answers:[
"Ask for clarification before completing the quote",
"Choose the document you like best",
"Ignore the conflict",
"Average the information from both documents"
],
correct:0,
explanation:"Clarifying discrepancies helps prevent quoting errors."
},

{
id:89,
module:2,
lesson:7,
category:"Document Review",
difficulty:"Medium",
product:"",
question:"Why is it valuable to compare the equipment schedule with the drawings?",
answers:[
"To verify they describe the same project scope",
"To determine paint colors",
"To calculate conduit fill",
"To estimate shipping weight"
],
correct:0,
explanation:"Comparing schedules with drawings helps identify inconsistencies."
},

{
id:90,
module:2,
lesson:7,
category:"Lesson Review",
difficulty:"Medium",
product:"",
question:"What is the primary goal of Lesson 7?",
answers:[
"Learning to compare project documents and identify items that should be verified",
"Programming addressable devices",
"Installing HVAC equipment",
"Performing detector maintenance"
],
correct:0,
explanation:"Lesson 7 develops document review skills that support accurate quoting and project coordination."
},

{
id:91,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: You receive revised mechanical drawings showing two additional Air Handling Units (AHUs). The fire alarm BOM has not changed. What is your first action?",
answers:[
"Review whether the fire alarm scope should also be updated",
"Immediately order additional smoke detectors",
"Ignore the change",
"Remove existing HVAC equipment from the quote"
],
correct:0,
explanation:"A revision affecting another building system should prompt a review of the fire alarm scope before assumptions are made."
},

{
id:92,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: The mechanical drawings contain revision clouds around new rooftop equipment. Why should you pay attention?",
answers:[
"The revisions may affect the fire alarm equipment required",
"The building address changed",
"The electrical service changed automatically",
"The detector sensitivity changed"
],
correct:0,
explanation:"Revision clouds identify changes that should be reviewed for possible impact on the fire alarm system."
},

{
id:93,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: A customer asks why you are reviewing mechanical drawings during a fire alarm quote. What is the best answer?",
answers:[
"Other building systems may require coordination with the fire alarm system",
"Mechanical drawings replace fire alarm drawings",
"They contain programming information",
"They determine battery size"
],
correct:0,
explanation:"Fire alarm systems often coordinate with HVAC and other building systems."
},

{
id:94,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: The equipment schedule lists additional HVAC equipment that is not shown on the original bid documents. What should you do?",
answers:[
"Verify which project documents are current before updating the quote",
"Ignore the equipment schedule",
"Automatically add products",
"Delete the original estimate"
],
correct:0,
explanation:"Always confirm which revision governs the project before making quote changes."
},

{
id:95,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: During a review, you discover conflicting information between two drawing revisions. What is the best practice?",
answers:[
"Request clarification before completing the quote",
"Average the information",
"Use whichever drawing has more pages",
"Ignore both drawings"
],
correct:0,
explanation:"Clarifying conflicts reduces the chance of quoting errors."
},

{
id:96,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: You notice several air handling units but are unsure whether the fire alarm design addresses them. What should you do?",
answers:[
"Review the project documents and verify the coordination",
"Assume the design is complete",
"Add products without approval",
"Ignore the HVAC equipment"
],
correct:0,
explanation:"Verification is better than assumption when reviewing project documents."
},

{
id:97,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Medium",
product:"",
question:"PROJECT: Which document is most useful for identifying HVAC equipment locations?",
answers:[
"Mechanical Drawings",
"Landscape Drawings",
"Furniture Layout",
"Finish Schedule"
],
correct:0,
explanation:"Mechanical drawings show HVAC equipment, ductwork, and related systems."
},

{
id:98,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Medium",
product:"",
question:"PROJECT: Before submitting a quote, why should you compare multiple drawing disciplines?",
answers:[
"To identify changes that may affect the fire alarm scope",
"To estimate paint quantities",
"To calculate speaker wattage",
"To determine shipping cost"
],
correct:0,
explanation:"Comparing disciplines helps identify coordination issues before the quote is released."
},

{
id:99,
module:2,
lesson:8,
category:"Final Project",
difficulty:"Hard",
product:"",
question:"PROJECT: A customer says the mechanical engineer made several late revisions. What is the safest response?",
answers:[
"Review the latest project documents before revising the quote",
"Ignore the revisions",
"Replace all smoke detectors",
"Automatically increase every quantity"
],
correct:0,
explanation:"Late revisions should always be reviewed before changing the estimate."
},

{
id:100,
module:2,
lesson:8,
category:"Module Review",
difficulty:"Medium",
product:"",
question:"After completing Module 2, what should you be most comfortable doing?",
answers:[
"Recognizing smoke detection concepts, reviewing HVAC coordination, and identifying items that should be verified during estimating",
"Programming every fire alarm panel",
"Performing annual inspections",
"Designing complete fire alarm systems"
],
correct:0,
explanation:"Module 2 builds practical knowledge for Sales Support by focusing on smoke detection fundamentals, document review, HVAC coordination, and disciplined verification."
},

{
id:101,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"EST4",
question:"Which EST4 capability supports remote status access without being tied to one device type?",
answers:[
"On-board webserver access",
"Local bell silence switch",
"A detector test magnet",
"A Class B NAC circuit"
],
correct:0,
explanation:"The EST4 platform documentation includes an on-board webserver for remote, device-independent access to status reports."
},

{
id:104,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"iO-Series Intelligent Fire Alarm Systems",
question:"Which feature pairing is associated with the iO-Series product family?",
answers:[
"Electronic addressing and automatic device mapping",
"Conventional only and no mapping",
"No Ethernet options and no addressing",
"Audio amplification and strobe synchronization only"
],
correct:0,
explanation:"The iO-Series library entry includes intelligent/electronic addressing and automatic device mapping."
},

{
id:106,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"EDGE-ML Fire Alarm Systems",
question:"Which capacity point is associated with the Edge Series entry?",
answers:[
"Up to 4 loops with up to 250 devices per loop",
"Single loop fixed at 64 devices",
"No remote annunciator support",
"Panel networking only, no loop support"
],
correct:0,
explanation:"The Edge entry includes support up to four loops and 250 devices per loop, with additional annunciator support noted in the product data."
},

{
id:107,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Hard",
product:"Signature Optica Smoke Heat and CO Detector",
question:"Which answer correctly identifies the Signature Optica smoke/heat/CO variant?",
answers:[
"A multi-criteria detector combining smoke, heat, and CO sensing",
"A control relay module",
"A low-frequency wall strobe",
"A communications bridge"
],
correct:0,
explanation:"The model name and official listing identify this as the multi-criteria smoke/heat/CO Signature Optica detector."
},

{
id:108,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"Signature Optica Smoke and CO Detector",
question:"How should Sales Support distinguish this Signature Optica model from the smoke/heat/CO variant?",
answers:[
"By confirming it is specifically the smoke-and-CO model",
"By assuming all Optica models include heat",
"By treating it as a notification appliance",
"By assigning it to Genesis"
],
correct:0,
explanation:"The model naming and library entries separate smoke-and-CO from smoke/heat/CO combinations."
},

{
id:109,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"Intelligent CO Detector",
question:"Which Edwards family includes the Intelligent CO Detector?",
answers:[
"Signature Series",
"EST4",
"Genesis",
"Edge Series"
],
correct:0,
explanation:"The updated Edwards product library groups the Intelligent CO Detector within Signature Series entries."
},

{
id:111,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"High Power Control Relay Module",
question:"Which use case matches a high power control relay module in fire alarm integration?",
answers:[
"Interfacing panel logic to controlled external circuits",
"Detecting smoke in HVAC ducts",
"Providing visible strobe output",
"Hosting network node programming"
],
correct:0,
explanation:"The high power control relay module is listed as an I/O control interface category device, not a detector or notification appliance."
},

{
id:112,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Hard",
product:"Signal Modules with Class A Operation",
question:"In this product listing, Class A operation is most closely tied to what concept?",
answers:[
"Return-path circuit topology for survivability goals",
"Detector sensitivity level",
"Network login permissions",
"Speaker wattage selection"
],
correct:0,
explanation:"The product description context links Class A operation to circuit topology in life safety output design."
},

{
id:113,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"Genesis LED G4 Series Wall Mount Notification Devices",
question:"Which configuration options are associated with Genesis notification devices?",
answers:[
"Selectable candela output and flash rate",
"Detector address map upload",
"Panel CPU frequency setting",
"Ground fault module isolation"
],
correct:0,
explanation:"The Genesis library language includes configurable candela and flash-rate options."
},

{
id:114,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Hard",
product:"Genesis LED G1 Series Compact Notification Devices",
question:"Why is it important to keep G1 compact models distinct in quoting?",
answers:[
"They are a compact notification category and should not be treated as detector or module products",
"They replace all control panels",
"They are network gateways",
"They are detector base adapters"
],
correct:0,
explanation:"The G1 line is categorized as compact notification appliances in Genesis, so it should be scoped as notification hardware."
},

{
id:115,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Medium",
product:"Genesis LED G4LF Series Low Frequency",
question:"When is the G4LF series most appropriate?",
answers:[
"When low-frequency signaling is part of the design basis",
"When a new SLC loop is needed",
"When adding control relays",
"When replacing EST3X network nodes"
],
correct:0,
explanation:"The G4LF entry is tied to low-frequency signaling applications controlled by panel output logic."
},

{
id:116,
module:2,
lesson:9,
category:"Edwards Product Library",
difficulty:"Hard",
product:"Genesis LED GCS Series Ceiling Mount Speakers and Speaker-Strobes",
question:"What best describes the GCS series role in a life safety system?",
answers:[
"Ceiling-mounted audible/visual notification endpoints driven by configured system logic",
"Loop isolator modules",
"Intelligent initiating detectors",
"Panel networking backbones"
],
correct:0,
explanation:"The GCS series is categorized as ceiling-mount speaker/speaker-strobe notification devices in the updated library."
},

{
id:117,
module:2,
lesson:9,
category:"BOM Recognition",
difficulty:"Medium",
product:"SIGA-DDOS Intelligent Duct Smoke Detector",
question:"A BOM lists a SIGA-DDOS and also lists a separate SIGA-CR for the same duct-detector relay function. What should you flag for review?",
answers:[
"A possible duplicated relay function, since the SIGA-DDOS already includes its own onboard auxiliary relay",
"Nothing — every duct detector always needs a separate relay",
"The SIGA-DDOS itself, since it cannot be used on this project",
"The SIGA-CR, since it is now an obsolete product"
],
correct:0,
explanation:"The SIGA-DDOS has a built-in auxiliary relay. If a separate relay is also listed for the same function, verify against the actual application before assuming both are required — the SIGA-CR may still be legitimately needed for a different function, but a duplicated relay for the same function should be flagged."
}

];